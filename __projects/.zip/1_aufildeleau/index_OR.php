<!DOCTYPE html>
<?php
// Start the session
session_start();
require_once('../../inc/define.php');
?>
<html >
  <head>
    <meta charset="UTF-8">
    <title><?php echo $_SESSION["NAME_PROJECT"];?></title>


        <!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js'></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.6.6/jquery.fullPage.min.js'></script> -->
        <script src='js/jquery-2.1.4.js'></script>


        <link rel='stylesheet prefetch' href='css/jquery.fullPage.css'>

        <link rel="stylesheet" href="css/style.css">




  </head>

  <body>

    <header>
  <div class="header-top clearfix">
    <h1 class="l-left"><a href="#firstSection">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION["NAME_PROJECT"];?></a></h1>
    <a class="l-right toggle-menu" href="#">
      <i></i>
      <i></i>
      <i></i>
    </a>
  </div>


<?php



// Si les données json sont dans un fichier distant:
$json = file_get_contents('localstorage_graph.txt');
// print_r($json); // all
// echo "<pre> ---------------------arrayID------------------------</pre>" ;
// Décode le JSON
$json_data = json_decode($json,true);
// echo '<pre>' . print_r($json_data, true) . '</pre>';
// print_r($json_data);

$arrayID = array();
foreach($json_data as $v){
   // echo '<pre>' . print_r($v) . '</pre>';
    $classes = $v['classes'];
    // echo '<pre>' . $classes . '</pre>';
    if($classes == 'cases'){
      
      $id_case = $v['data']['id'];
      $arrayID[] = $id_case;
      // echo '<pre>' . $id_case . '</pre>';
    }
    
   // echo '<pre>' . print_r($v['data']['target']) . '</pre>';
  // $a = $v['data']['target'];
  //  // array_push($arrayTarget, $a);
  // if(!empty($a) || $a === 0){
  //   $arrayTarget[] = $a;
  // }
}

// $arrayTarget = array_filter($arrayTarget);
// echo '<pre>' . print_r($arrayID) . '</pre>';


// echo "<pre> ---------------------arrayTarget------------------------</pre>" ;

$arrayTarget = array();
foreach($json_data as $v){
   // echo '<pre>' . print_r($v) . '</pre>';
   // echo '<pre>' . print_r($v['data']) . '</pre>';
   // echo '<pre>' . print_r($v['data']['target']) . '</pre>';
  $s = $v['data']['source'];
  $t = $v['data']['target'];
   // array_push($arrayTarget, $a);
  if(!empty($t) || $t === 0){
    $arrayTarget[$s] = $t;
  }
}

// $arrayTarget = array_filter($arrayTarget);
// echo '<pre>' . print_r($arrayTarget) . '</pre>';


// -----------------------------------------------------

$arrayTarget = array_unique(array_filter($arrayTarget));
// echo '<pre>' . print_r($arrayTarget) . '</pre>';

// foreach ($json_data as $v => $value) {
//     // Use $vand $value here
//   echo '<pre>' . print_r($v['target']) . '</pre>';
// }

// print_r($arrayTarget);

// foreach ($arrayTarget as $target => $t) {
//   echo '<pre>' .  $t . '</pre>';
// }




//echo "<pre> ------------------ID_first_case------------------------------</pre>" ;

$arID=array_diff($arrayID,$arrayTarget);
// print_r($arID);
$ID_first_case = array_values($arID)[0];
//echo '<pre> id : ' . $ID_first_case . '</pre>';

//echo "<pre> ------------------- get chained cases ------------------------</pre>" ;


// foreach($json_data as $v){
//   $s = $v['data']['source'];
//   $t_id = $v['data']['target'];
//    array_push($arrayTarget, $a);
//   if($s == $ID_first_case){
//     echo '<pre> t_id : ' . $t_id . '</pre>';
//   }
// }

// function get_target_ID_DES($s){
//   $target_ID = $arrayTarget['7'];
//   echo '<pre> target_id : ' . $target_ID . '</pre>';

// }
// $test = array();
// define("TEST",$test);
// const TEST = array();

// $ids = array();
// $ids[] = $ID_first_case;
// $CHAIN_ID = $ID_first_case;
$_SESSION["CHAIN_ID"] = $ID_first_case; // todo better
$iterator = new RecursiveIteratorIterator(new RecursiveArrayIterator($arrayTarget));
function get_target_ID($source,$iterator){
  // echo "get_target_ID";
    //$test = $ids;
    foreach ($iterator as $key => $target) {
        if ($key === intval($source)) {
          // echo '<pre>' . $target . '</pre>';
          // $test[] = $value;
          // $CHAIN_ID = $CHAIN_ID . '-' . $value;
          // TEST[] = $value;
          // echo '<pre>' . print_r($ids) . '</pre>';

$_SESSION["CHAIN_ID"] = $_SESSION["CHAIN_ID"]. '-' . $target;
    // $CHAIN_ID = $CHAIN_ID . '-' . $value;
    //echo '<pre>' . $CHAIN_ID . '</pre>'; 

          get_target_ID($target,$iterator);
          // break;
          // return $ids;
          
        }
    // echo '<pre>' . print_r($ids) . '</pre>'; 
    // return $ids;



    }

    
}

// echo "<pre> ------------------- get chained cases array ------------------------</pre>" ;

get_target_ID($ID_first_case,$iterator);

// echo "<pre> ------------------- END get chained cases array ------------------------</pre>" ;

// print_r($idsS);
// echo '<pre>' . $idsS . '</pre>';

// echo '<pre>' . $_SESSION["CHAIN_ID"] . '</pre>';
$_SESSION["CHAIN_ID"] = $_SESSION["CHAIN_ID"] . "-END-END"; // todo better
$IDS_CHAINED_NODES = explode("-",$_SESSION["CHAIN_ID"]);
echo '<pre>' . var_dump($IDS_CHAINED_NODES) . '</pre>';
// exit;

?>


  <nav class="hide">
    <ul id="menu">
      <li data-menuanchor="firstSection">
        <a href="#firstSection" title="First Section">First Section</a>
      </li>
      <li data-menuanchor="secondSection">
        <a href="#secondSection" title="Second Section">Second Section</a>
      </li>
      <li data-menuanchor="thirdSection">
        <a href="#thirdSection" title="Second Section">Third Section</a>
      </li>
      <li data-menuanchor="fourthSection">
        <a href="#fourthSection" title="Fourth Section">Fourth Section</a>
      </li>
      <li data-menuanchor="fifthSection">
        <a href="#fifthSection" title="First Slide">First Slide</a>
      </li>
      <li data-menuanchor="sixSection">
        <a href="#sixSection" title="First Slide">Six Slide</a>
      </li>

      <li data-menuanchor="sevenSection">
        <a href="#sevenSection" title="First Slide">Seven Slide</a>
      </li>

<!--       <li data-menuanchor="fifthSection/1">
        <a href="#fifthSection/1" title="Second Slide">Second Slide</a>
      </li> -->
    </ul>
  </nav>
</header>


<style>

.section-contain {
    /*background-image: url('http://lorempixel.com/g/500/500/');*/
    background-repeat: no-repeat;
    background-size: contain;
    /*background-size: cover;*/

}
</style>

<div id="fullpage">

<?php
foreach ($IDS_CHAINED_NODES as $id) {
  // echo '<pre>' . $id . '</pre>';
  $id = "5";
  echo '<section class="vertical-scrolling section-contain" id="case_'.$id.'">';
  echo '<h2 style="z-index:100;color:white;">'.$id.'</h2>';
  echo '</section>';
}
// exit;
// foreach ($IDS_CHAINED_NODES as $ID => $t) {
//   echo '<section class="vertical-scrolling section-contain" id="case_'.$t.'">';
//   echo '</section>';
// }


?>

  <section class="vertical-scrolling" style="background-color: transparent;">
    <div class="horizontal-scrolling section-contain"  style="background-color: transparent;" id="case_5">
      <h2>fullPage.js</h2>
      <h3>This is the fifth section and it contains the first slide (actually section == first slide)</h3>
    </div>
    <div class="horizontal-scrolling section-contain">
      <!-- <h2>fullPage.js</h2>
      <h3>This is the second slide</h3> -->
      <p class="end">Fin</p>
      <div class="section-contain" id="case_6" style="width:100%;height:100%;">fin</div>
    </div>
  </section>



<!--   <section class="vertical-scrolling section-contain" id="case_1">

  </section>


  <section class="vertical-scrolling section-contain" id="case_2">
    <h2>fullPage.js</h2>
    <h3>This is the second section</h3>
  </section>
  <section class="vertical-scrolling section-contain" id="case_3">
    <h2>fullPage.js</h2>
    <h3>This is the third section</h3>
  </section>
  <section class="vertical-scrolling section-contain" id="case_4">
    <h2>fullPage.js</h2>
    <h3>This is the fourth section</h3>
  </section>
 -->



</div>

        <script src='js/jquery.fullPage.min.js'></script>
        <script src="js/index.js"></script>

<script>
        imageUrl = '../../__projects/1_aufildeleau/cases/case_6/case_6_bg.jpg?'+<?php echo date("YmdHis");?>;
        $('#case_6').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_9/case_9_bg.jpg';
        $('#case_9').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_3/case_3_bg.jpg';
        $('#case_3').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_2/case_2_bg.jpg';
        $('#case_2').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_1/case_1_bg.jpg';
        $('#case_1').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_6/case_6_bg.jpg';
        $('#case_6').css('background-image', 'url(' + imageUrl + ')');
</script>

  </body>
</html>

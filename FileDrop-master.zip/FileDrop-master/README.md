jQuery.FileDrop.js
==================

A simple way to add file drag-n-drop to your web projects.

##[View Docs & Demo](http://chrismbarr.github.io/FileDrop/)

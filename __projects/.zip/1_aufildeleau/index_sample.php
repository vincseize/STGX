<!DOCTYPE html>
<?php
require_once('../../inc/define.php');
?>
<html >
  <head>
    <meta charset="UTF-8">
    <title><?php echo $_SESSION["NAME_PROJECT"];?></title>


        <!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js'></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.6.6/jquery.fullPage.min.js'></script> -->
        <script src='js/jquery-2.1.4.js'></script>


        <link rel='stylesheet prefetch' href='css/jquery.fullPage.css'>

        <link rel="stylesheet" href="css/style.css">




  </head>

  <body>

    <header>
  <div class="header-top clearfix">
    <h1 class="l-left"><a href="#firstSection">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION["NAME_PROJECT"];?></a></h1>
    <a class="l-right toggle-menu" href="#">
      <i></i>
      <i></i>
      <i></i>
    </a>
  </div>


<?php

$arrayTarget = array();

// Si les données json sont dans un fichier distant:
$json = file_get_contents('localstorage_graph.txt');
// print_r($json); // all
// Décode le JSON
$json_data = json_decode($json,true);
// echo '<pre>' . print_r($json_data, true) . '</pre>';
// print_r($json_data);
foreach($json_data as $v){
   // echo '<pre>' . print_r($v) . '</pre>';
   // echo '<pre>' . print_r($v['data']) . '</pre>';
   // echo '<pre>' . print_r($v['data']['target']) . '</pre>';
  $a = $v['data']['target'];
   // array_push($arrayTarget, $a);
  if(!empty($a) || $a === 0){
    $arrayTarget[] = $a;
  }
}

$arrayTarget = array_unique(array_filter($arrayTarget));

// echo '<pre>' . print_r($arrayTarget) . '</pre>';

// foreach ($json_data as $v => $value) {
//     // Use $vand $value here
//   echo '<pre>' . print_r($v['target']) . '</pre>';
// }

// print_r($arrayTarget);

foreach ($arrayTarget as $target => $t) {
  echo '<pre>' .  $t . '</pre>';
}


?>


  <nav class="hide">
    <ul id="menu">
      <li data-menuanchor="firstSection">
        <a href="#firstSection" title="First Section">First Section</a>
      </li>
      <li data-menuanchor="firstSectionBIS">
        <a href="#firstSectionBIS" title="First SectionBIS">First SectionBIS</a>
      </li>
      <li data-menuanchor="secondSection">
        <a href="#secondSection" title="Second Section">Second Section</a>
      </li>
      <li data-menuanchor="thirdSection">
        <a href="#thirdSection" title="Second Section">Third Section</a>
      </li>
      <li data-menuanchor="fourthSection">
        <a href="#fourthSection" title="Fourth Section">Fourth Section</a>
      </li>
      <li data-menuanchor="fifthSection">
        <a href="#fifthSection" title="First Slide">First Slide</a>
      </li>
      <li data-menuanchor="fifthSection/1">
        <a href="#fifthSection/1" title="Second Slide">Second Slide</a>
      </li>
    </ul>
  </nav>
</header>


<style>

.section-contain {
    /*background-image: url('http://lorempixel.com/g/500/500/');*/
    background-repeat: no-repeat;
    background-size: contain;
    /*background-size: cover;*/

}
</style>

<div id="fullpage">


  <section class="vertical-scrolling section-contain" id="case_1">
      <!-- <div class="bigslide"> -->
                <h2>fullPage.js</h2>
                <h3>This is the first section</h3>
<!--                 <div class="scroll-icon">
                  <p>Jump into the last slide</p>
                  <a href="#fifthSection/1" class="icon-up-open-big"></a>
                </div> -->
            <!-- </div> -->
  </section>

  <section class="vertical-scrolling section-contain" id="case_1bis">
      <!-- <div class="bigslide"> -->
                <h2>fullPage.js</h2>
                <h3>This is the first sectionBIS</h3>
<!--                 <div class="scroll-icon">
                  <p>Jump into the last slide</p>
                  <a href="#fifthSection/1" class="icon-up-open-big"></a>
                </div> -->
            <!-- </div> -->
  </section>


  <section class="vertical-scrolling section-contain" id="case_2">
    <h2>fullPage.js</h2>
    <h3>This is the second section</h3>
  </section>
  <section class="vertical-scrolling section-contain" id="case_3">
    <h2>fullPage.js</h2>
    <h3>This is the third section</h3>
  </section>
  <section class="vertical-scrolling section-contain" id="case_4">
    <h2>fullPage.js</h2>
    <h3>This is the 4 section</h3>
  </section>
  <section class="vertical-scrolling section-contain" id="case_5">
    <h2>fullPage.js</h2>
    <h3>This is the 5 section</h3>
  </section>
  <section class="vertical-scrolling" style="background-color: transparent;">
    <div class="horizontal-scrolling section-contain"  style="background-color: transparent;" id="case_6">
      <h2>fullPage.js</h2>
      <h3>This is the 6 section and it contains the first slide (actually section == first slide)</h3>
    </div>
    <div class="horizontal-scrolling section-contain">
      <!-- <h2>fullPage.js</h2>
      <h3>This is the second slide</h3> -->
      <p class="end">Fin</p>
      <div class="section-contain" id="case_7" style="width:100%;height:100%;">7 fin</div>
    </div>
  </section>
</div>

        <script src='js/jquery.fullPage.min.js'></script>
        <script src="js/index.js"></script>

<script>
        imageUrl = '../../__projects/1_aufildeleau/cases/case_15/case_15_bg.jpg?'+<?php echo date("YmdHis");?>;
        $('#case_1').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_2/case_2_bg.jpg';
        $('#case_2').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_3/case_3_bg.jpg';
        $('#case_3').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_4/case_4_bg.jpg';
        $('#case_4').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_5/case_5_bg.jpg';
        $('#case_5').css('background-image', 'url(' + imageUrl + ')');
        imageUrl = '../../__projects/1_aufildeleau/cases/case_6/case_6_bg.jpg';
        $('#case_6').css('background-image', 'url(' + imageUrl + ')');
</script>

  </body>
</html>

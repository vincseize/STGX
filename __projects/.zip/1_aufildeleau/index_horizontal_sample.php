<!DOCTYPE html>
<?php
// Start the session
session_start();
require_once('../../inc/define.php');
include('get_chain.php');
?>


<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>STG | <?php echo $_SESSION["NAME_PROJECT"];?></title>
	<meta name="author" content="$author" />
	<meta name="description" content="Storygraph" />
	<meta name="keywords"  content="$keywords" />
	<meta name="Resource-type" content="Document" />


	<link rel="stylesheet" type="text/css" href="_css/jquery.fullPage.css" />
	<link rel="stylesheet" type="text/css" href="_css/examples.css" />

<!-- 	// js after css !!! -->
	<script type="text/javascript" src="_js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="_js/jquery-ui.1.9.1.min.js"></script>

	<script type="text/javascript" src="_js/jquery.fullPage.js"></script>
	<script type="text/javascript" src="_js/examples.js"></script>


<style>

/* Style for our header texts
	* --------------------------------------- */
	
	body {
	  font-size: 40px;
	  font-family: arial, helvetica;
	  color: #000;
	  margin: 0;
	  padding: 0;
	}
	
	h1 {
	  font-weight: normal;
	  font-size: inherit
	}
	
	#fp-nav {
	  display: none;
	}
	
	.section {
	  text-align: center;
	  background: pink;
	}
	
	.num {
	  position: absolute;
	  top: 15px;
	  left: 15px;
	  text-align: left;
	  z-index: 100;
	}

</style>


<script type="text/javascript">
	
$(document).ready(function() {



  $('#fullpage').fullpage({

  	sectionsColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', 'whitesmoke', '#ccddff'],
	anchors: ['firstPage', 'secondPage', 'thirdPage', 'fourthPage', 'lastPage'],
	menu: '#menu',

	afterRender: function() {
	console.log('afterRender');
	$(".fp-next").show();
	// $.fn.fullpage.setAllowScrolling(false, 'left, right');
	//$.fn.fullpage.setAllowScrolling(false);
	// $.fn.fullpage.moveSlideLeft(false);
	//$.fn.fullpage.moveSlideRight();
	},

    afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {
	
			var loadedSlide = $(this);
			var totalItems = loadedSlide.siblings().length;
			var numContainer = loadedSlide.closest('.fp-section').find('.num');
			var id = loadedSlide.closest('.slide').attr('id');
			numContainer.html("0" + slideIndex + ' / ' + totalItems + ' / ' + id);

			$(".fp-controlArrow").show();
			$(".fp-prev").show();
			$(".fp-next").show();

			if(id == "slide1"){
			    $(".fp-prev").hide();
			}
			if(id == "slide10"){
			    $(".fp-next").hide();
			}
    },

	afterLoad: function(anchorLink, index) {
		var loadedSlide = $(this);
		var id = loadedSlide.closest('.slide').attr('id');

		$(".fp-controlArrow").hide();
		// $(".fp-next").show();
		// $(".fp-prev").show();

		if(id == "slide1"){
		    $(".fp-prev").hide();
		    $(".fp-next").show();
		}
		if(id == "slide10"){
			$(".fp-prev").show();
		    $(".fp-next").hide();
		}

	},

    onSlideLeave: function (anchorLink, index, slideIndex, direction, nextSlideIndex) {
            var loadedSlide = $(this);
            var id = loadedSlide.closest('.slide').attr('id');
			// if(id == "slide10"){
			// 	$(".fp-prev").show();
			//     $(".fp-next").hide();
			//     var nextSlideIndex = slideIndex;
			// }
    }



  });


});

</script>





</head>
<body>


<ul id="menu">
	<!-- <li data-menuanchor="firstPage" class="active"><a href="#firstPage/1">1</a></li> -->
	<li data-menuanchor="firstPage" class="active"><a href="#firstPage/">1</a></li>
	<li data-menuanchor="secondPage"><a href="#firstPage/1">2</a></li>
	<li data-menuanchor="thirdPage" ><a href="#firstPage/2">3</a></li>
	<li data-menuanchor="fourthPage"><a href="#firstPage/3">4</a></li>
	<li data-menuanchor="fifthPage"><a href="#firstPage/4">5</a></li>
</ul>


<div id="fullpage">

	  <div class="section">

<!-- 		    <div class="slide active" id="slide1">
		      <h1>S1</h1>
		  </div> -->

		    <div class="slide" id="slide1">
		      <h1>S1</h1>
		  </div>

		    <div class="slide" id="slide2">
		      <h1>S2</h1></div>

		    <div class="slide" id="slide3">
		      <h1>S3</h1></div>

		    <div class="slide" id="slide4">
		      <h1>S4</h1></div>

		    <div class="slide" id="slide5">
		      <h1>S5</h1></div>

		    <div class="slide" id="slide6">
		      <h1>S6</h1></div>

		    <div class="slide" id="slide7">
		      <h1>S7</h1></div>

		    <div class="slide" id="slide8">
		      <h1>S8</h1></div>

		    <div class="slide" id="slide9">
		      <h1>S9</h1></div>

		    <div class="slide" id="slide10">
		      <h1>S10</h1></div>

		      
		    <div class="num"></div>


	  </div>

</div>




</body>
</html>
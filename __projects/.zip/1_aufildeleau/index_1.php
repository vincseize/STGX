<!DOCTYPE html>
<?php
// Start the session
session_start();
require_once('../../inc/define.php');
?>

<?php



// Si les données json sont dans un fichier distant:
$json = file_get_contents('localstorage_graph.txt');
// print_r($json); // all
// echo "<pre> ---------------------arrayID------------------------</pre>" ;
// Décode le JSON
$json_data = json_decode($json,true);
// echo '<pre>' . print_r($json_data, true) . '</pre>';
// print_r($json_data);

$arrayID = array();
foreach($json_data as $v){
   // echo '<pre>' . print_r($v) . '</pre>';
    $classes = $v['classes'];
    // echo '<pre>' . $classes . '</pre>';
    if($classes == 'cases'){
      
      $id_case = $v['data']['id'];
      $arrayID[] = $id_case;
      // echo '<pre>' . $id_case . '</pre>';
    }
    
   // echo '<pre>' . print_r($v['data']['target']) . '</pre>';
  // $a = $v['data']['target'];
  //  // array_push($arrayTarget, $a);
  // if(!empty($a) || $a === 0){
  //   $arrayTarget[] = $a;
  // }
}

// $arrayTarget = array_filter($arrayTarget);
// echo '<pre>' . print_r($arrayID) . '</pre>';


// echo "<pre> ---------------------arrayTarget------------------------</pre>" ;

$arrayTarget = array();
foreach($json_data as $v){
   // echo '<pre>' . print_r($v) . '</pre>';
   // echo '<pre>' . print_r($v['data']) . '</pre>';
   // echo '<pre>' . print_r($v['data']['target']) . '</pre>';
  $s = $v['data']['source'];
  $t = $v['data']['target'];
   // array_push($arrayTarget, $a);
  if(!empty($t) || $t === 0){
    $arrayTarget[$s] = $t;
  }
}

// $arrayTarget = array_filter($arrayTarget);
// echo '<pre>' . print_r($arrayTarget) . '</pre>';


// -----------------------------------------------------

$arrayTarget = array_unique(array_filter($arrayTarget));
// echo '<pre>' . print_r($arrayTarget) . '</pre>';

// foreach ($json_data as $v => $value) {
//     // Use $vand $value here
//   echo '<pre>' . print_r($v['target']) . '</pre>';
// }

// print_r($arrayTarget);

// foreach ($arrayTarget as $target => $t) {
//   echo '<pre>' .  $t . '</pre>';
// }




//echo "<pre> ------------------ID_first_case------------------------------</pre>" ;

$arID=array_diff($arrayID,$arrayTarget);
// print_r($arID);
$ID_first_case = array_values($arID)[0];
//echo '<pre> id : ' . $ID_first_case . '</pre>';

//echo "<pre> ------------------- get chained cases ------------------------</pre>" ;


// foreach($json_data as $v){
//   $s = $v['data']['source'];
//   $t_id = $v['data']['target'];
//    array_push($arrayTarget, $a);
//   if($s == $ID_first_case){
//     echo '<pre> t_id : ' . $t_id . '</pre>';
//   }
// }

// function get_target_ID_DES($s){
//   $target_ID = $arrayTarget['7'];
//   echo '<pre> target_id : ' . $target_ID . '</pre>';

// }
// $test = array();
// define("TEST",$test);
// const TEST = array();

// $ids = array();
// $ids[] = $ID_first_case;
// $CHAIN_ID = $ID_first_case;
$_SESSION["CHAIN_ID"] = $ID_first_case; // todo better
$iterator = new RecursiveIteratorIterator(new RecursiveArrayIterator($arrayTarget));
function get_target_ID($source,$iterator){
  // echo "get_target_ID";
    //$test = $ids;
    foreach ($iterator as $key => $target) {
        if ($key === intval($source)) {
          // echo '<pre>' . $target . '</pre>';
          // $test[] = $value;
          // $CHAIN_ID = $CHAIN_ID . '-' . $value;
          // TEST[] = $value;
          // echo '<pre>' . print_r($ids) . '</pre>';

$_SESSION["CHAIN_ID"] = $_SESSION["CHAIN_ID"]. '-' . $target;
    // $CHAIN_ID = $CHAIN_ID . '-' . $value;
    //echo '<pre>' . $CHAIN_ID . '</pre>'; 

          get_target_ID($target,$iterator);
          // break;
          // return $ids;
          
        }
    // echo '<pre>' . print_r($ids) . '</pre>'; 
    // return $ids;



    }

    
}

// echo "<pre> ------------------- get chained cases array ------------------------</pre>" ;

get_target_ID($ID_first_case,$iterator);

// echo "<pre> ------------------- END get chained cases array ------------------------</pre>" ;

// print_r($idsS);
// echo '<pre>' . $idsS . '</pre>';

// echo '<pre>' . $_SESSION["CHAIN_ID"] . '</pre>';
$_SESSION["CHAIN_ID"] = $_SESSION["CHAIN_ID"]; // todo better
$IDS_CHAINED_NODES = explode("-",$_SESSION["CHAIN_ID"]);
echo '<pre>' . var_dump($IDS_CHAINED_NODES) . '</pre>';
// exit;

?>





<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo $_SESSION["NAME_PROJECT"];?></title>
	<meta name="author" content="Alvaro Trigo Lopez" />
	<meta name="description" content="Storygraph" />
	<meta name="keywords"  content="fullpage,jquery,alvaro,trigo,plugin,fullscren,screen,full,iphone5,apple" />
	<meta name="Resource-type" content="Document" />


	<link rel="stylesheet" type="text/css" href="jquery.fullPage.css" />
	<link rel="stylesheet" type="text/css" href="examples.css" />


	<style>

		/* Sections
		 * --------------------------------------- */
		#section0 img,
		#section1 img{
			margin: 20px 0 0 0;
		}
		#section2 img{
			margin: 20px 0 0 52px;
		}
		#section3 img{
			bottom: 0px;
			position: absolute;
			margin-left: -420px;
		}
		.intro p{
			width: 50%;
			margin: 0 auto;
			font-size: 1.5em;
		}
		.twitter-share-button{
			position: absolute;
			z-index: 99;
			right: 149px;
			top: 9px;
		}

	</style>
	<!--[if IE]>
		<script type="text/javascript">
			 var console = { log: function() {} };
		</script>
	<![endif]-->

	<script src="jquery.min.1.8.3.js"></script>
	<script src="jquery-ui.min.1.9.1.js"></script>

	<script type="text/javascript" src="jquery.fullPage.js"></script>
	<script type="text/javascript" src="examples.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#fullpage').fullpage({
				sectionsColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', 'whitesmoke', '#ccddff'],
				anchors: ['firstPage', 'secondPage', '3rdPage', '4thpage', 'lastPage'],
				menu: '#menu',
				scrollingSpeed: 1000
			});

		});
	</script>

<style>

.div-slide {
    /*background-image: url('http://lorempixel.com/g/500/500/');*/
    background-repeat: no-repeat;
    background-size: contain;
    /*background-size: cover;*/
    width:100%;
    height:100%;
    padding:0;
    margin:0;

}
</style>

</head>
<body>



<ul id="menu">
<!-- 	<li data-menuanchor="firstPage"><a href="#firstPage">First slide</a></li> -->
	<li data-menuanchor="secondPage"><a href="#secondPage">Second slide</a></li>
<!-- 	<li data-menuanchor="3rdPage"><a href="#3rdPage">Third slide</a></li>
	<li data-menuanchor="4thpage"><a href="#4thpage">Fourth slide</a></li> -->
</ul>


<!-- <div id="fullpage">

	<div class="section active" id="section1">


		<div id="case_TITLE" class="slide div-slide">
			<div class="intro">
				<h1><?php echo $_SESSION["NAME_PROJECT"];?></h1>
			</div>
		</div>


		<?php
			foreach ($IDS_CHAINED_NODES as $id) {
			  echo '<div id="case_'.$id.'" class="slide div-slide">';
				  echo '<div class="intro">';
				  echo '<h1>'.$id.'</h1>';
				  echo '</div>';
			  echo '</div>';
			}
		?>


		<div id="case_END" class="slide div-slide">
			<div class="intro">
				<h1>FIN</h1>
			</div>
		</div>


	</div>
 -->
</div>





<?php
$myStringArray_ids_ext_DES = array(
    "title" => "JavaScript: The Definitive Guide",
    "author" => "David Flanagan",
    "edition" => 6
);
?>
<!-- <script type="text/javascript">


console.log("-------------------XXXXXX-----------------------");



$.get( "ids_ext.php", function( data ) {

  console.log(JSON.stringify(data));
  console.log(data);
  myStringArray_ids_ext = JSON.parse(data);
});



var myStringArray_ids_ext = <?php echo json_encode($myStringArray_ids_ext, JSON_PRETTY_PRINT) ?>;

console.log(myStringArray_ids_ext.title);


		for (var key in myStringArray_ids_ext) {

		  		console.log("R key " + key + " has R value " + myStringArray_ids_ext[key]);
		  		var ext = myStringArray_ids_ext[key];

		}



console.log("-------------------XXXXXX-----------------------");


</script>

 -->



<script>


// $.getJSON('ids.php', function(data) {
//   var items = [];

//   $.each(data, function(key, val) {
//     items.push('<li id="' + key + '">' + val + '</li>');
//   });

//   $('<ul/>', {
//     'class': 'my-new-list',
//     html: items.join('')
//   }).appendTo('body');
// });


console.log("-------------------A-----------------------");

var url = "storygraph-json.php";



$.ajax({
        type: "GET", 
        url: url, 
        // data: form_data,
        success: function(response)
        {
            /*response = '[{"Language":"jQuery","ID":"1"},{"Language":"C#","ID":"2"},
                           {"Language":"PHP","ID":"3"},{"Language":"Java","ID":"4"},
                           {"Language":"Python","ID":"5"},{"Language":"Perl","ID":"6"},
                           {"Language":"C++","ID":"7"},{"Language":"ASP","ID":"8"},
                           {"Language":"Ruby","ID":"9"}]'
            console.log(response);
            */
	    	var json_obj = $.parseJSON(response);//parse JSON
            var output="<ul>";
            for (var i in json_obj) 
            {
                output+="<li>" + json_obj[i].Language + ",  " + json_obj[i].ID + "</li>";
                console.log(json_obj[i].classes + ",  " + json_obj[i].id + ",  " + json_obj[i].ext);
            }
            output+="</ul>";
            
            $('span').html(output);
        },
        dataType: "json"//set to JSON    
}) 

































$.get( url, function( data ) {

 obj = JSON.parse(data);

// alert(obj.count);

	console.log('data');
	console.log(data);
  // console.log(JSON.encode(data));
  console.log(typeof(data));
  // var book = <?php echo json_encode($data, JSON_PRETTY_PRINT) ?>;
  // console.log(book);
  // console.log(JSON.decode(data));
  // var result = JSON.stringify(data);


		// for (var key in data) {
		// 	console.log(key);
		// 	console.log("R key " + key + " has R value " + data[key]);
		// }

		// for (var key in result) {
		// 	console.log("R key " + key + " has R value " + result[key]);
		// }


});



		// for (var key in result) {
		// 	if(key == id){
		//   		console.log("R key " + key + " has R value " + result[key]);
		//   		var ext = result[key];
		// 	}
		// }


console.log("--------------------B----------------------");







        // imageUrl = '../../__projects/1_aufildeleau/cases/case_7/case_7_bg.jpg';
        // $('#case_7').css('background-image', 'url(' + imageUrl + ')');


// var myStringArray_ID = ["7","6","9","3","2"];
// var arrayLength = myStringArray_ID.length;


// var myStringArray = {7:'jpg',6:'jpg',9:'jpg',3:'png',2:'jpg'};



// var result = '{"7":"jpg","6":"jpg","9":"jpg","3":"jpg","2":"jpg","3":"jpg"}';


// $.each($.parseJSON(result), function(k, v) {
//     console.log(k + ' is ' + v);
// });




for (var i = 0; i < arrayLength; i++) {
		id = myStringArray_ID[i];
		// alert(id);
		// id = "7";

		// for (var key in myStringArray) {
		// 	if(key == id){
		//   		console.log("key " + key + " has value " + myStringArray[key]);
		//   		var ext = myStringArray[key];
		// 	}
		// }


        var imageUrl = 'cases/case_'+id+'/case_'+id+'_bg.'+ext+'';
		var id_div = "#case_"+id;
        $(id_div).css('background-image', 'url(' + imageUrl + ')');
        // alert(id_div);
        // alert(imageUrl);
}


		<?php

			  // echo $imageUrl = '../../__projects/1_aufildeleau/cases/case_7/case_7_bg.jpg';
			  // echo "$('#case_7').css('background-image', 'url(".$imageUrl.")');";

			// foreach ($IDS_CHAINED_NODES as $id) {
			//   echo $imageUrl = '../../__projects/1_aufildeleau/cases/case_7/case_7_bg.jpg';
			//   echo "$('#case_7').css('background-image', 'url(".$imageUrl.")');";
			// }
		?>

        // imageUrl = '../../__projects/1_aufildeleau/cases/case_7/case_7_bg.jpg';
        // $('#case_7').css('background-image', 'url(' + imageUrl + ')');

        // imageUrl = '../../__projects/1_aufildeleau/cases/case_6/case_6_bg.jpg';
        // $('#case_6').css('background-image', 'url(' + imageUrl + ')');

        // imageUrl = '../../__projects/1_aufildeleau/cases/case_9/case_9_bg.jpg';
        // $('#case_9').css('background-image', 'url(' + imageUrl + ')');

        // imageUrl = '../../__projects/1_aufildeleau/cases/case_3/case_3_bg.png';
        // $('#case_3').css('background-image', 'url(' + imageUrl + ')');

        // imageUrl = '../../__projects/1_aufildeleau/cases/case_2/case_2_bg.jpg';
        // $('#case_2').css('background-image', 'url(' + imageUrl + ')');




</script>

</body>
</html>
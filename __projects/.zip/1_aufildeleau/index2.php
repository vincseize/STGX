<!DOCTYPE html>
<?php
// Start the session
session_start();
require_once('../../inc/define.php');
include('get_chain.php');
?>


<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>STG | <?php echo $_SESSION["NAME_PROJECT"];?></title>
	<meta name="author" content="Alvaro Trigo Lopez" />
	<meta name="description" content="Storygraph" />
	<meta name="keywords"  content="fullpage,jquery,alvaro,trigo,plugin,fullscren,screen,full,iphone5,apple" />
	<meta name="Resource-type" content="Document" />


	<link rel="stylesheet" type="text/css" href="_css/jquery.fullPage.css" />
	<link rel="stylesheet" type="text/css" href="_css/examples.css" />

<!-- 	// js after css !!! -->
	<script type="text/javascript" src="_js/jquery.1.8.3.min.js"></script>
	<script type="text/javascript" src="_js/jquery-ui.1.9.1.min.js"></script>

	<script type="text/javascript" src="_js/jquery.fullPage.js"></script>
	<script type="text/javascript" src="_js/examples.js"></script>

	<style>

		/* Sections
		 * --------------------------------------- */
		#section0 img,
		#section1 img{
			margin: 20px 0 0 0;
		}
		#section2 img{
			margin: 20px 0 0 52px;
		}
		#section3 img{
			bottom: 0px;
			position: absolute;
			margin-left: -420px;
		}
		.intro p{
			width: 50%;
			margin: 0 auto;
			font-size: 1.5em;
		}
		.twitter-share-button{
			position: absolute;
			z-index: 99;
			right: 149px;
			top: 9px;
		}

	</style>
	<!--[if IE]>
		<script type="text/javascript">
			 var console = { log: function() {} };
		</script>
	<![endif]-->



<style>

.div-slide {
    /*background-image: url('http://lorempixel.com/g/500/500/');*/
    background-repeat: no-repeat;
    background-size: contain;
    /*background-size: cover;*/
    width:100%;
    height:100%;
    padding:0;
    margin:0;

}

/*#case_TITLE .fp-prev{
    opacity:0.5;
}*/

#callbacks-placeholder{
  position:fixed;bottom:50px;left:150px;right:150px;color:black;z-index:999;
  background: yellow;
  opacity: 0.7;
}

</style>

</head>
<body>



<ul id="menuX" style="display:block;">
<!-- 	<li data-menuanchor="firstPage"><a href="#firstPage">First slide</a></li> -->
<!-- 	<li data-menuanchor="secondPage"><a href="#case_2">Cese 2 slide</a></li> -->
<!-- 	<li data-menuanchor="3rdPage"><a href="#3rdPage">Third slide</a></li>
	<li data-menuanchor="4thpage"><a href="#4thpage">Fourth slide</a></li> -->
		<li data-menuanchor="Title"><a href="#case_TITLE">TITLE</a></li>
		<?php
			foreach ($IDS_CHAINED_NODES as $id) {
			  echo '<li data-menuanchor="Page '.$id.'"><a href="#case_'.$id.'">Case '.$id.'</a></li>';
			}
		?>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
<!-- 		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li>
		<li data-menuanchor="End"><a href="#case_END">FIN</a></li> -->

</ul>


<div id="fullpage"  style="display:none;">

	<div class="section active" id="section1">


		<div id="case_TITLE" class="slide div-slide">
			<div class="intro" id="case_TITLE">
				<h1><?php echo $_SESSION["NAME_PROJECT"];?></h1>
			</div>
		</div>


<!-- 		<?php
			foreach ($IDS_CHAINED_NODES as $id) {
			  echo '<div id="case_'.$id.'" class="slide div-slide">';
				  echo '<div class="intro" id="case_'.$id.'>';
				  echo '<h1>'.$id.'</h1>';
				  echo '</div>';
			  echo '</div>';
			}
		?> -->


		<div id="case_END" class="slide div-slide">
			<div class="intro" id="case_END">
				<h1>FIN</h1>
			</div>
		</div>


	</div>

</div>

<div id="callbacks-placeholder">za</div>


<script type="text/javascript">


var deleteLog = false;
var placeHolder = $('#callbacks-placeholder');

		$('#fullpage').fullpage({
			sectionsColor: ['#1bbc9b', '#4BBFC3', '#7BAABE', 'whitesmoke', '#ccddff'],
			anchors: ['firstPage', 'secondPage', '3rdPage', '4thpage', 'lastPage'],

// $('.fp-section.active').find('.fp-slide.active');


    // anchors: ['firstPage', 'secondPage', 'thirdPage', 'fourthPage', 'lastPage'],
    // afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {
    //   var loadedSlide = $(this);
    //   var totalItems = loadedSlide.siblings().length;
    //   var numContainer = loadedSlide.closest('.fp-section').find('.num');
    //   var id = loadedSlide.closest('.slide').attr('id');
    //   numContainer.html("0" + slideIndex + ' / ' + totalItems + ' / ' + id);


// onLeave: function(index, nextIndex, direction) {
// if (deleteLog) {
//   placeHolder.html('');
// }
// placeHolder.append('<p>onLeave - index:' + index + ' nextIndex:' + nextIndex + ' direction:' + direction + '</p>')
// },
// onSlideLeave: function(anchorLink, index, slideIndex, direction, nextSlideIndex) {
// if (deleteLog) {
//   placeHolder.html('');
// }
// placeHolder.append('<p>onSlideLeave - anchorLink:' + anchorLink + " index:" + index + " slideIndex:" + slideIndex + " direction:" + direction + " nextSlideIndex:" + nextSlideIndex + '</p>');
// },
// afterRender: function() {
// placeHolder.append('<p>afterRender</p>');;
// },
// afterResize: function() {
// placeHolder.append('<p>afterResize</p>');
// },
afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex) {
placeHolder.append('<p>afterSlideLoad - anchorLink:' + anchorLink + " index:" + index + " slideAnchor:" + slideAnchor + " slideIndex:" + slideIndex + '</p>');



deleteLog = true;
$(".fp-controlArrow").show();
$(".fp-next").show();
$(".fp-prev").show();
        if(index == 1 && slideIndex == 0){
            alert("1 slide loaded 2");
            $(".fp-prev").hide();
        }
        if(index == 1 && slideIndex == 7){
            alert("1 slide loaded 2");
            $(".fp-next").hide();
        }
},
afterLoad: function(anchorLink, index) {
	var loadedSection = $(this);
	var id = loadedSection.attr("id");
placeHolder.append('<p>afterLoad - anchorLink:' + anchorLink + " index:" + index + " id:" + id + '</p>');
// console.log(id);


$(".fp-controlArrow").show();
$(".fp-next").show();
$(".fp-prev").show();

        if(index == 1 && id == "section1"){
            //alert("1 slide loaded 2");
            $(".fp-prev").hide();
        }


    // var loadedSection = $(this);
    
    
    // console.log(loadedSection.attr("id"));
    // var SAsection-active = $('.fp-section.active').find('.fp-slide.active');
    var SAsectionActive = $('.fp-section.active');
    console.log('SA : '+ SAsectionActive.attr("id"));
    var SAsection = loadedSection.attr("id");
    var SAslide = loadedSection.find('.fp-slide.active');
    console.log('id section act :'+SAsection);
    console.log('id slide act : '+SAslide.attr("id"));



},
// afterResponsive: function(isResponsive){
// placeHolder.append('<p>afterResponsive - isResponsive:' +isResponsive + '</p>');
// },


			menu: '#menu',
			scrollingSpeed: 1000
		});



	$(document).ready(function() {




	});

// When all loaded
$(window).load(function() {
  
		if (document.readyState === "complete" 
		     || document.readyState === "loaded" 
		     || document.readyState === "interactive") {
		     // document has at least been parsed

		 	console.log("document has at least been parsed");







	var url = "storygraph-json.php";

	function populateCases() {
	    getJson(function(json_obj) {
	        //processing the data
	        // console.log(json_obj);
	        // var json_obj = $.parseJSON(json_obj);//parse JSON
	        for (var i in json_obj) 
	            {
	            	// ------------------ case json
	            	// console.log(json_obj[i]); // ["cases","7","jpg"]
	                var classes = json_obj[i][0];
	                var id = json_obj[i][1];
	                var ext = json_obj[i][2];
	                console.log(classes + ",  " + id + " ,  " + ext);

	            	// ------------------ case json_string
	                // console.log(json_obj[i].classes + ",  " + json_obj[i].id + ",  " + json_obj[i].ext);
	                // var classes = json_obj[i].classes;
	                // var id = json_obj[i].id;
	                // var ext = json_obj[i].ext;
	                // if(ext!=""){
	                if(ext){
				        var imageUrl = 'cases/case_'+id+'/case_'+id+'_bg.'+ext+'';
						var id_div = "#case_"+id;
				        $(id_div).css('background-image', 'url(' + imageUrl + ')');                	
	                }


	            }

	    });
	}


	function getJson(callback) {
	    var data;
	    $.ajax({
	        url: url,
	        dataType: "json", //set to JSON
	        success: function (resp) {
	            data = resp;
	            callback(data);
	        },
	        error: function () {}
	    }); // ajax asynchronus request 
	    //the following line wouldn't work, since the function returns immediately
	    //return data; // return data from the ajax request
	}


	populateCases();



	$('#fullpage').fadeIn()






		}



});

function getID(id) {
	console.log(id);
}

</script>

<script>












</script>






</body>
</html>